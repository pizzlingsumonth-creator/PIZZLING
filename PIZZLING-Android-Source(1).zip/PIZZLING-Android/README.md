# PIZZLING Android project

This project wraps the supplied PIZZLING HTML app in an Android WebView. The in-app `.piz` / `.html` update manager updates the HTML app layer and preserves WebView local storage where the app's existing update logic supports it. It does **not** silently replace the Android APK or update native Android code. Native changes require building and installing a newly signed APK with the same signing key/package identity.

## Build
GitHub Actions runs on push to `main` or manually via Actions -> Build PIZZLING APK -> Run workflow. Download the `PIZZLING-APK` artifact.
