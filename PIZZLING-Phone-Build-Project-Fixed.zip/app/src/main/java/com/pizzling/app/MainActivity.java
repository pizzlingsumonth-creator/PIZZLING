package com.pizzling.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> upload;
    private static final int PICK = 42;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (upload != null) upload.onReceiveValue(null);
                upload = cb;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, PICK);
                    return true;
                } catch (ActivityNotFoundException e) {
                    upload = null;
                    cb.onReceiveValue(null);
                    return false;
                } catch (Exception e) {
                    upload = null;
                    cb.onReceiveValue(null);
                    return false;
                }
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK && upload != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            upload.onReceiveValue(results);
            upload = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
