package com.pizzling.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
public class MainActivity extends Activity {
 private WebView web; private ValueCallback<Uri[]> upload; private static final int PICK=42;
 @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); web.setWebChromeClient(new WebChromeClient(){ public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){ if(upload!=null) upload.onReceiveValue(null); upload=cb; Intent i=p.createIntent(); startActivityForResult(i,PICK); return true; }}); setContentView(web); web.loadUrl("file:///android_asset/index.html"); }
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d); if(r==PICK && upload!=null){upload.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c,d)); upload=null;}}
 @Override public void onBackPressed(){if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed();}
}
